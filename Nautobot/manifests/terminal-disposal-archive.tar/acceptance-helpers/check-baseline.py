import json,sys
from pathlib import Path
root=Path(__file__).resolve().parent
expected=json.loads((root/'baseline.json').read_text())
observed=json.loads(Path(sys.argv[1]).read_text())
skip={'collected_at','staging_free_bytes','timers'}
checks={k:observed.get(k)==v for k,v in expected.items() if k not in skip}
timers=lambda x:sorted((r['unit'],r['activates']) for r in json.loads(x['timers']))
checks['timer_identities']=timers(expected)==timers(observed)
print(json.dumps({'preflight_passed':all(checks.values()),'checks':checks},sort_keys=True))
raise SystemExit(0 if all(checks.values()) else 1)
