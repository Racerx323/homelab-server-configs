#!/bin/bash
set -euo pipefail
cd /
exec /usr/sbin/runuser --user nautobot -- /usr/bin/env HOME=/var/lib/nautobot XDG_RUNTIME_DIR=/run/user/999 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/999/bus PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -B - <<'PY_TARGET'
import hashlib,json,os,stat,subprocess,sys,shutil
from datetime import datetime,timezone
from pathlib import Path
root=Path('/var/lib/nautobot/protection/qualification')
sys.path.insert(0,str(root/'scripts'))
import recurring_node as node
op=node.load(root/'operation.json');state=node.load(root/'state/state.json');before=node.load(root/'state/before.json')
run=Path(state['root']);assert run.parent==root.parent/'staging'
def tree(base):
 files={};directories={};total=0
 paths=[base,*base.rglob('*')];assert len(paths)<256
 for p in paths:
  info=p.lstat();assert stat.S_ISDIR(info.st_mode) or stat.S_ISREG(info.st_mode)
  row={'uid':info.st_uid,'gid':info.st_gid,'mode':stat.S_IMODE(info.st_mode)}
  if p.is_file():
   assert p.name not in ('password','credentials.json','source-password','source-credentials.json','doppler-service-token')
   assert info.st_size<16*1024**2
   total+=info.st_size;assert total<64*1024**2
   row['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
  (directories if p.is_dir() else files)[str(p.relative_to(base))]=row
 return {'files':files,'directories':directories}
props='ActiveState,SubState,InvocationID,ExecMainStartTimestamp,MainPID,ControlPID,ControlGroup,Result'
units={name:dict(line.split('=',1) for line in node.system(['show',name,'--property='+props]).decode().strip().splitlines()) for name in op['unit_names']}
services=node.health(); payload=tree(run)
receipt=node.load(run/'application-capture-result.json')
creds=Path(op['binding']['credentials']['token_file']);ci=creds.lstat()
record={'collected_at':datetime.now(timezone.utc).isoformat(),'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'uid':os.getuid(),'gid':os.getgid(),'services':services,'data_services_unchanged':all(services['nautobot-'+r+'.service']['InvocationID']==before['services']['nautobot-'+r+'.service']['InvocationID'] for r in ('postgresql','redis')),'units':units,'jobs':node.system(['list-jobs','--no-legend','--no-pager']).decode().strip(),'state':state,'qualification':tree(root),'payload':{'path':str(run),**payload},'staging_entries':sorted(p.name for p in run.parent.iterdir()),'links':{n:os.readlink(Path('/run/user/999/systemd/user')/n) if (Path('/run/user/999/systemd/user')/n).is_symlink() else None for n in op['unit_names']},'artifacts_match':all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in op['baseline']['artifact_sha256'].items()),'binding_artifacts_match':all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in op['binding']['artifact_sha256'].items()),'packages_match':all(node.bounded(['/usr/bin/dpkg-query','-W','-f=${Version} ${Architecture}',r['name']]).decode()==r['version']+' '+r['architecture'] for r in op['packages']),'credential_metadata_match':all(node.load(Path(op['binding']['credentials']['metadata_file'])).get(k)==v for k,v in op['credential_identity'].items()),'credential_file_metadata':{'uid':ci.st_uid,'gid':ci.st_gid,'mode':stat.S_IMODE(ci.st_mode),'regular':stat.S_ISREG(ci.st_mode)},'media_directories':node.media_directories(),'staging_free_bytes':shutil.disk_usage(run.parent).free,'filesystem':node.bounded(['/usr/bin/findmnt','-no','SOURCE,FSTYPE','-T',str(run.parent)]).decode().strip(),'timers':node.system(['list-timers','--all','--no-pager','--output=json']).decode(),'native_dump_valid':None,'payload_hashes_match':None,'secret_values_read':False,'mutation':False}
old=root.with_name('qualification-retained-307ef354afe5');record['earlier_retained']=tree(old)
record['old_payload']=tree(Path('/var/lib/nautobot/protection/staging/nautobot-recurring.v9u1oyjm'))
record['preserved_terminal']=tree(root.with_name('qualification-retained-bdf8247fd17a'))
record['runtime_links_present']={n:os.path.lexists(Path('/run/user/999/systemd/user')/n) for n in op['unit_names']}
record['new_result']=node.load(root/'result.json') if (root/'result.json').exists() else None
record['preserved_readiness_terminal']=tree(root.with_name('qualification-retained-e007c8d42f73'))
record['previous_readiness_payload']=tree(Path('/var/lib/nautobot/protection/staging/nautobot-recurring.156jog6b'))
record['task_results']=node.load(run/'capture-task-results.json') if (run/'capture-task-results.json').exists() else None
record['resume_verification']=node.load(run/'capture-resume-verification.json') if (run/'capture-resume-verification.json').exists() else None
record['capture_specification']=node.load(run/'application-backup.json')
record['restic_version']=node.bounded(['/usr/bin/restic','version']).decode().strip()
record['restic_sha256']=hashlib.sha256(Path('/usr/bin/restic').read_bytes()).hexdigest()
upload=root.parent/'upload-qualification'
record['upload_result']=node.load(upload/'result.json') if (upload/'result.json').exists() else None
record['upload_cleanup']=node.load(upload/'cleanup.json') if (upload/'cleanup.json').exists() else None
record['upload_unit']=dict(line.split('=',1) for line in node.system(['show','nautobot-protection-upload-qualification.service','--property='+props]).decode().strip().splitlines())
record['upload_receipts']={n:node.load(run/n) for n in ('application-backup-result.json','application-snapshots-before.json','application-snapshots-after.json') if (run/n).exists()}
record['notification_evidence_absent']=not os.path.lexists(root.parent/'notification-qualification')
record['notification_unit']=dict(line.split('=',1) for line in node.system(['show','nautobot-notification-qualification.service','--property='+props]).decode().strip().splitlines())
notification=root.parent/'notification-qualification'
record['notification_tree']=tree(notification) if notification.is_dir() else None
record['notification_result']=node.load(notification/'result.json') if (notification/'result.json').exists() else None
record['notification_queue']=node.load(notification/'state/notification.json') if (notification/'state/notification.json').exists() else None
record['disposal_evidence_absent']=not os.path.lexists(root.parent/'disposal-qualification')
record['disposal_marker_absent']=not os.path.lexists(run/'payload-disposal.json')
record['disposal_unit']=dict(line.split('=',1) for line in node.system(['show','nautobot-disposal-qualification.service','--property='+props]).decode().strip().splitlines())
record['payload_file_metadata']={n:{'bytes':(run/'payload'/n).lstat().st_size,'nlink':(run/'payload'/n).lstat().st_nlink,'device':(run/'payload'/n).lstat().st_dev,'inode':(run/'payload'/n).lstat().st_ino} for n in receipt['content_sha256'] if (run/'payload'/n).exists()}
record['restic_forget_help']=node.bounded(['/usr/bin/restic','forget','--help']).decode()
disposal=root.parent/'disposal-qualification'
record['disposal_receipts']={n:node.load(disposal/n) if (disposal/n).exists() else None for n in ('result.json','cleanup.json','retention-analysis.json','repository-commands.json','claimed.json')}
record['payload_disposal']=node.load(run/'payload-disposal.json') if (run/'payload-disposal.json').exists() else None
record['disposal_runtime_sha256']={str(p.relative_to(disposal)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [disposal/'operation.json',disposal/'ansible.cfg',*[disposal/'scripts'/n for n in ('disposal_qualification.py','recurring_disposal.py','recurring_delivery.py','recurring_protection.py','capture_retained.py','application-backup.py')]] if p.is_file()}
credential_root=disposal/'credentials'
record['disposal_credential_directory']={'exists':credential_root.is_dir(),'entries':sorted(p.name for p in credential_root.iterdir()) if credential_root.is_dir() else None}
if credential_root.is_dir():
 info=credential_root.lstat();record['disposal_credential_directory'].update(uid=info.st_uid,gid=info.st_gid,mode=stat.S_IMODE(info.st_mode))
print(json.dumps(record,sort_keys=True))
PY_TARGET
