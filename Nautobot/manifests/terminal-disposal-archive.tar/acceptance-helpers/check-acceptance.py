"""Independent local postconditions and retained read-only repository receipts."""
import json,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
before=json.loads((p/'baseline.json').read_text());after=json.loads((p/'readback.json').read_text());op=json.loads((p/'candidate/runtime/operation.json').read_text())
changed={'collected_at','staging_free_bytes','timers','payload','native_dump_valid','payload_hashes_match','disposal_evidence_absent','disposal_marker_absent','disposal_unit','payload_file_metadata'}
checks={'preserved_'+k:after.get(k)==v for k,v in before.items() if k not in changed}
timers=lambda x:sorted((r['unit'],r['activates']) for r in json.loads(x['timers']))
checks['timer_identities']=timers(before)==timers(after)
old=before['payload'];new=after['payload'];oldfiles={k:v for k,v in old['files'].items() if not k.startswith('payload/')};newfiles={k:v for k,v in new['files'].items() if k!='payload-disposal.json'}
checks['only_payload_files_removed']=oldfiles==newfiles and new['directories']==old['directories'] and after['payload_file_metadata']=={}
marker=after['payload_disposal'];checks['complete_marker']=marker=={'phase':'complete','snapshot_id':op['snapshot_id'],'files':sorted(op['content_sha256'])}
metadata=new['files']['payload-disposal.json'];checks['protected_marker']=metadata['uid']==999 and metadata['gid']==985 and metadata['mode']==384
receipts=after['disposal_receipts'];result=receipts['result.json'];report=receipts['retention-analysis.json'];commands=receipts['repository-commands.json']
checks['controller_exit_zero']=json.loads((p/'execution/controller-result.json').read_text())['exit_status']==0
checks['node_checks']=result['checks_passed'] and result['disposal_complete'] and result['credential_cleanup'] and result['accepted'] is False
checks['cleanup_receipt']=all(receipts['cleanup.json'].values())
checks['credentials_removed']=after['disposal_credential_directory']=={'exists':True,'entries':[],'uid':999,'gid':985,'mode':448}
checks['read_only_analysis']=report['read_only'] and report['repository_unchanged'] and report['deletion_authorized'] is False
checks['policy']=report['policy']==['forget','--dry-run','--json','--host','j2-svpi4mf','--tag','nautobot-recurring','--group-by','host,tags','--keep-daily','7','--keep-weekly','5','--keep-monthly','12']
checks['inventory']=sorted(r['id'] for r in report['inventory'])==sorted(op['snapshot_ids'])
checks['independent_inventory_comparison']=sorted(report['inventory'],key=lambda r:r['id'])==sorted(report['inventory_after'],key=lambda r:r['id']) and report['repository_id']==op['repository']['id']
checks['selection']=set(report['keep'])|set(report['would_remove'])==set(op['eligible_snapshot_ids']) and op['snapshot_id'] in report['keep'] and not set(report['would_remove']).intersection(op['protected_snapshot_ids'])
checks['historical_exclusions']=report['excluded']==sorted(op['protected_snapshot_ids'])
checks['exact_read_commands']=[c['arguments'] for c in commands]==[['cat','config'],['snapshots','--json'],report['policy'],['snapshots','--json']] and all(c['exit_status']==0 for c in commands)
unit=after['disposal_unit'];checks['unit_inactive']=unit['ActiveState']=='inactive' and unit['MainPID']=='0' and unit['ControlPID']=='0' and not unit['ControlGroup']
expected={str(f.relative_to(p/'candidate/runtime')):hashlib.sha256(f.read_bytes()).hexdigest() for f in (p/'candidate/runtime').rglob('*') if f.is_file()}
checks['runtime_hashes']=after['disposal_runtime_sha256']==expected
out={'accepted':all(checks.values()),'checks':checks};(p/'acceptance-checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out));raise SystemExit(0 if out['accepted'] else 1)
