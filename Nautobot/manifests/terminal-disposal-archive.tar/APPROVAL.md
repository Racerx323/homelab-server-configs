# Local disposal and remote retention-analysis approval request

Prepared only. No target mutation, provider contact, credential resolution or
payload/snapshot deletion occurred during preparation. Repository execution is disabled.

Approve one execution of bundle `cd1e1d5f9efded646d71da1dd53448a4ff64c9851cf6625bc06724f6fc2c677e` on `ama@10.1.2.170`
(`j2-svpi4mf`), as Nautobot UID 999/GID 985. Source base:
`7fc50d26b3fca6366e6c3fd4bf9077a71265933d`, plus the exact frozen candidate files.
This combines **one local successful-payload disposal** with **remote retention
analysis only**, as requested. It does not authorize remote snapshot deletion or prune.

## Exact local disposition

Remove only these six files beneath `/var/lib/nautobot/protection/staging/nautobot-recurring.usiv2ym1/payload`:

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `configuration` | 20480 | `cd9f960fb85c9d620c0568d079c0eae1ca00c82b4d05ec9cb844e2c276994bb2` |
| `image_dependency_manifest` | 20480 | `e00b1afd19528bec6df100529e03cff9195e35c4f0b0d475e85f0c1449aad31f` |
| `media` | 10240 | `6a271e232bcfb3d9ad7894a1febcd790e424d7623fcbc8b4aaf045374f586b04` |
| `postgresql_custom_dump` | 5127742 | `3fa820b04b3605ba0a72c899890b45c16949c0ca677702d91dd4dfcf757bc919` |
| `quadlet_config_hashes` | 30720 | `a3c235c5f740cee51158983f7de122ff627f72c93333018431626e8ae87869a0` |
| `versions_migrations` | 53827 | `1271747b9ce460b3c05ab185108363d6ca21a50cb98909a3c8ff4007c39ca025` |

Total: **5,263,489 bytes**. Exact device/inode/link
identities and owned-tree hashes are also bound in `candidate/operation.yaml`.
Retain the empty payload directory, every existing receipt, the capture state and
all other payloads, including older failed captures and restore/preservation data.
Preserve frozen evidence, consumed claims and latches. Add only the local
`payload-disposal.json` receipt and the new protected operation evidence tree.

Recovery source: accepted full snapshot
`4aa30449f76dd29b319422dd6e9e525f0bb7036a8979ab3de87931a5ed6b2c24` in repository `536d6d1dc29c7c6ea79eed972efb43cc37445fe0be73d0bf8518e2771394f8a9`.
The accepted November 3 upload and full integrity check are historical evidence;
fresh remote existence and provenance are required before local deletion.

Local unlink has **no automatic undo**. Recovery would retrieve the exact retained
snapshot into new protected staging through a separate reviewed restore scope.
This trial does not establish current-snapshot application-restore or populated-media
recovery acceptance. No in-place restoration is authorized here.

## Remote retention analysis and preservation

Use repository `s3:https://s3.us-west-002.backblazeb2.com/theama-homelab-nautobot-restic-prd/` with the pinned `/usr/bin/restic`
(`restic 0.18.0 compiled with go1.24.4 on linux/arm64`). Confirm its ID, list snapshots, run the exact dry-run
policy below, then list snapshots again. Every command includes `--no-lock`,
`--no-cache`, the exact repository URL and a protected password-file path.
`TZ=America/Chicago` is explicit. No cache or repository lock objects are created.

```text
cat config
snapshots --json
forget --dry-run --json --host j2-svpi4mf --tag nautobot-recurring --group-by host,tags --keep-daily 7 --keep-weekly 5 --keep-monthly 12
snapshots --json
```

The complete five-snapshot inventory expected from the accepted upload receipt is
bound in the operation. Only the accepted recurring snapshot above is eligible for
this initial analysis. Its stable host/tag identity prevents unique staging paths
from splitting the retention group. Require that snapshot in the keep set; record
full keep/remove IDs and before/after inventories. All four historical snapshots
below are excluded and protected:

- `028d50637353e7f901c563f2ec63a1adba3c954195e15f130a5e801959fa9219`
- `7a86d7a5d0748ec72d5a99be099be0922958b290662324a4c416b6825a5f5cf3`
- `7f59d7ccb20ccf6e3c4ea537034db77e0ec558b7a01e7cb2d1bb2bd62b77863c`
- `cde42adbda73d29a98beb62d5fb4c339c10c826a5bc64f0460fb0bc884777051`

This is a historical expected inventory, not a fresh provider observation. Missing,
additional, ambiguously tagged or changed snapshots stop the stage before local
disposal. Empty selection or a protected reference in the remove set also refuses.
With only one eligible snapshot, no removal is expected; that remains unconfirmed
until the approved remote analysis runs. All remote snapshots remain retained even
if a dry run identifies candidates. No retagging, non-dry-run forget, prune, unlock,
repair, repository initialization or provider-policy changes are included.

**Execution precondition:** the operator excludes concurrent repository maintenance
for the bounded run. The local capture locks serialize this producer, but a
lock-free remote inventory comparison is not a repository-wide exclusion lock.
Do not proceed if concurrent maintenance cannot be excluded. A future deletion
request must re-evaluate exact snapshot IDs under exclusive maintenance; prune is
another authorization, not an implied follow-up.

## Credentials and bounded execution

Use only the existing accepted read-only Doppler token for
`homelab-dev/prd_nautobot_backup`, with its accepted expiry and ownership. Resolve
only the three canonical references:

- `NAUTOBOT_RESTIC_REPOSITORY_PASSWORD` from `homelab-dev/prd_restic`.
- `NAUTOBOT_RESTIC_B2_APPLICATION_KEY_ID` from `homelab-dev/prd_b2`.
- `NAUTOBOT_RESTIC_B2_APPLICATION_KEY` from `homelab-dev/prd_b2`.

No new token, provider configuration or permanent credential file is created.
The resolver uses the accepted config-scoped copies and places transient output in
`/var/lib/nautobot/protection/disposal-qualification/credentials`, owned by Nautobot,
with 0700 directories and 0600 files. Secret values stay out of argv and receipts.
AWS values exist only in the Restic subprocess environment. Normal and stop-post
cleanup remove the two known files; unknown residue is retained and fails acceptance.
Credentials are removed before any local payload deletion.

One reusable Ansible playbook creates the absent evidence directory, transfers only
runtime inputs and invokes `nautobot-disposal-qualification.service`. Runtime is
limited to 420 seconds, stop to 30 seconds, with control-group termination. Remote
reads share a 180-second deadline and bounded output. No retries or scheduled units
are installed. Require both existing capture locks, completed capture state, exact
retained trees, reviewed file identities, executable hashes and healthy unchanged
services. After analysis and credential removal, repeat local verification before
calling the existing no-follow, directory-relative disposal implementation.

No writer pause, application restart, backup, notification, SMART request, package
change, reboot, schedule enablement, other payload deletion or publication is included.

## Exact commands

From this protected request directory, with `umask 077`, first refresh and verify
the authorized read-only baseline. It was prepared at `2026-11-03T21:24:37.740374+00:00`;
all 48 comparison checks passed against accepted notification readback.

```sh
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=10 ama@10.1.2.170 'cd / && sudo -n /bin/bash -s' < /home/aaron/code/.local-evidence/nautobot-disposal-retention-preparation-20261103/baseline.sh > /home/aaron/code/.local-evidence/nautobot-disposal-retention-preparation-20261103/pre-execution.json 2> /home/aaron/code/.local-evidence/nautobot-disposal-retention-preparation-20261103/pre-execution.stderr
python3 -B /home/aaron/code/.local-evidence/nautobot-disposal-retention-preparation-20261103/check-baseline.py /home/aaron/code/.local-evidence/nautobot-disposal-retention-preparation-20261103/pre-execution.json
```

Proceed only if both exit zero and the maintenance precondition holds. Then run once:

```sh
python3 -B /home/aaron/code/.local-evidence/nautobot-disposal-retention-preparation-20261103/candidate/launcher.py execute /home/aaron/code/.local-evidence/nautobot-disposal-retention-preparation-20261103/candidate --approve cd1e1d5f9efded646d71da1dd53448a4ff64c9851cf6625bc06724f6fc2c677e --evidence /home/aaron/code/.local-evidence/nautobot-disposal-retention-preparation-20261103/execution
```

The launcher verifies every frozen member and the controller executable, claims
the bundle once, and invokes Ansible through the repository temporary-directory
wrapper. Do not edit/re-freeze the candidate or replay a consumed claim.

## Independent acceptance and failure handling

Collect the approved post-disposal readback without trying to reopen removed files:

```sh
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=10 ama@10.1.2.170 'cd / && sudo -n /bin/bash -s' < /home/aaron/code/.local-evidence/nautobot-disposal-retention-preparation-20261103/readback.sh > /home/aaron/code/.local-evidence/nautobot-disposal-retention-preparation-20261103/readback.json 2> /home/aaron/code/.local-evidence/nautobot-disposal-retention-preparation-20261103/readback.stderr
python3 -B /home/aaron/code/.local-evidence/nautobot-disposal-retention-preparation-20261103/check-acceptance.py
```

Require zero controller status; exactly six removed files; unchanged empty-directory
ownership, existing receipts and retained capture tree; a protected complete marker
with the accepted snapshot; unchanged older payloads/evidence, application identities
and timers; zero credential residue; exact runtime hashes; and an inactive unit
without processes. Independently compare the retained before/after remote inventory
and full selection against the operation, including exclusion of every protected ID.
The node keeps `accepted=false`; only all independent checks permit reconciliation.

An interrupted or partial deletion is manual intervention. Preserve the marker,
remaining files, operation receipts and one-use claim. Never retry unlink, clear
existing latches, delete an unknown path, or claim rollback from an empty directory.
If still running, stop only the bounded operation unit:

```sh
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=10 ama@10.1.2.170 'sudo -n /usr/sbin/runuser --user nautobot -- /usr/bin/env HOME=/var/lib/nautobot XDG_RUNTIME_DIR=/run/user/999 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/999/bus /usr/bin/systemctl --user stop nautobot-disposal-qualification.service'
```

Verify stop-post credential cleanup and no remaining processes. Do not send a
notification or restore/delete additional data as automatic recovery. A failed
preflight retains all payload files; after unlink begins there is no automatic rollback.

## Qualification and remaining inputs

Eight qualification tests passed, using actual local Restic backup, full check,
dry-run selection, deletion and restore; sparse days/months and unique paths;
unrelated recovery-reference exclusion; inventory drift and lock refusal;
interrupted partial deletion and replay refusal; and the actual Ansible/user-service
path. Repository bytes were unchanged during analysis, and a fresh restore matched
all deleted local-file hashes. The local provider CLI and D-Bus probe are disposable
adapters; these tests do not establish target or provider acceptance.

Existing media/bindings/supervisor/disposal regressions: 43 passed. Operation
contracts: 17; documentation: 5; host convergence: 16. Schema, Ansible syntax through
the temporary-directory wrapper, assertion policy, YAML and bundle secret scan passed.

Remaining inputs: approval of this exact bundle and exclusion of concurrent
repository maintenance during execution. Fresh remote selection, protected credential
cleanup and target disposal remain live acceptance gaps. Historical/failed-payload
cleanup, remote snapshot deletion, prune, remaining recovery gates and schedules
remain later scopes. Commit/tag/push is not included in this live-stage request.

## Bound external read-only inputs

- `baseline.json`: `226fcdf155a9a01347b298470595b0760acd2205ecac3012789c83beb090cf9f`
- `baseline.sh`: `a463a9d7a1b838ac151db2f2963f984a919db337327c9fb2673cc99692656b7e`
- `check-baseline.py`: `9f34793c1844db9d9fc90a92e23effbd50a35961404dcb62672b49f54c39f703`
- `readback.sh`: `05ac1495c0efd09185b56a71d7894cae246af820b92668e68071042022ff18da`
- `check-acceptance.py`: `b3c89611b9f313cb4ba67de7ed5c1e3cc38cd80b0e29c768b886cb5f3ebf5f20`

Sanitized decisions and local evidence hashes: `Nautobot/manifests/recurring-disposal-review.json`.
