# Independent recovery and timer qualification approval request

Prepared only. Approve one execution of bundle `bb2e3c00d26e1bb1610c50ab1a680b835b6124ccdd471765ec198e0b38128043` on
`ama@10.1.2.170` (`j2-svpi4mf`), as Nautobot UID 999/GID 985.
Repository execution is disabled. No production fault, provider credential resolution,
unit transfer, timer activation or writer pause occurred during preparation.

The previous request was approved after its latest start. Its bundle and unused
claim are preserved. This replacement changes only the attended window and
refreshed baseline identity; executable inputs are byte-identical.

## Attended window and deadlines

**November 3, 2026, 17:30–18:30 CST (America/Chicago).** Begin the first trial
by **18:00 CST** so the bounded 30-minute sequence fits. Do not execute outside this
window; an expired window requires a replacement reviewed definition, not a changed
clock or an edited approved bundle. Aaron remains available while the node recovers
without controller assistance. Exclude concurrent writer, backup and maintenance
operations during this window.

Each trial retains the 450-second capture/guard deadline and shared 240-second
recovery ceiling. Native health has its existing 210-second limit and can use only
the remaining recovery budget after primary quiescence and writer resume. The
controller ceiling for both serial trials is 1,800 seconds. Stop the sequence after
any failure; never replay the one-use claim. No unattended production schedule is
authorized by this attended qualification.

## Exact mutation boundary

Create `/var/lib/nautobot/protection/recovery-qualification`, protected 0700 and
service-owned, and transfer only the frozen runtime inputs. Each case gets its own
state and new staging run under `/var/lib/nautobot/protection/staging`. Preserve all
existing capture, upload, notification, disposal and failed-trial evidence, latches,
claims, receipts, payloads and mapped media permissions.

Run these cases once, in order, through one Ansible playbook:

1. `killed`: real native preparation and Doppler resolution, then the existing
   scheduler/web stop, native worker drain and worker stop. Replace capture only
   with a blocking fault after the independent guard is armed and all writers are
   stopped. Send SIGKILL only to `nautobot-protection-killed.service` and its cgroup.
   Require the independent OnFailure recovery to stop the primary, attempt all three
   writer starts, verify native readiness and remove transient credentials.
2. `deadline`: repeat in separate protected state using
   `nautobot-protection-deadline.service`. Do not inject termination. Let its
   450-second guard timer stop the primary and perform the same independent recovery.
   The second trial runs only after the first has passed its checks and cleaned up.
3. Parse the proposed 03:20 backup and 04:05 freshness calendars across spring and
   autumn DST with the target's installed parser. Start a runtime-only two-second
   `nautobot-protection-timerqual.timer` whose service only touches its new protected
   marker. Stop and remove its runtime links. Do not enable a recurring timer.

Each recovery case links only its primary service, guard timer, guard service and
recovery service under `/run/user/999/systemd/user`. Remove those links after proven
recovery and release only the expected failed primary record. Do not install or
enable nightly, freshness or notification timers. PostgreSQL and Redis remain
running; no migration, reboot, SMART request, package/monitoring change, capture
payload, upload, remote Restic access, snapshot deletion, prune, notification or
older-payload disposal is included.

## Credential boundary

Use the existing accepted config-scoped read-only Doppler token for
`homelab-dev/prd_nautobot_backup`, owned by Aaron, expiring January 27, 2027,
with rotation due January 13. Resolve only the canonical repository password
(`homelab-dev/prd_restic/NAUTOBOT_RESTIC_REPOSITORY_PASSWORD`) and B2 key ID/key
(`homelab-dev/prd_b2/NAUTOBOT_RESTIC_B2_APPLICATION_KEY_ID` and
`homelab-dev/prd_b2/NAUTOBOT_RESTIC_B2_APPLICATION_KEY`). No new token, provider
configuration or permanent credential file. Keep transient credentials 0600 inside
service-owned 0700 staging. Do not log or read their values during inspection.
Recovery removes the four known transient credential names; any residue fails
acceptance and remains for scoped intervention.

## Exact command and preflight

From `/home/aaron/code/.local-evidence/nautobot-recovery-timer-window-20261103`, with `umask 077`, refresh the bounded read-only baseline:

```sh
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=10 ama@10.1.2.170 'cd / && sudo -n /bin/bash -s' < baseline.sh > pre-execution.json 2> pre-execution.stderr
python3 -B check-baseline.py pre-execution.json > pre-execution-checks.json
```

Proceed only if both return zero, the window and maintenance exclusion hold, and
the new evidence path and bundle claim are absent. Run exactly once:

```sh
python3 -B /home/aaron/code/.local-evidence/nautobot-recovery-timer-window-20261103/candidate/launcher.py execute /home/aaron/code/.local-evidence/nautobot-recovery-timer-window-20261103/candidate --approve bb2e3c00d26e1bb1610c50ab1a680b835b6124ccdd471765ec198e0b38128043 --evidence /home/aaron/code/.local-evidence/nautobot-recovery-timer-window-20261103/execution
```

The launcher verifies every frozen member and controller executable, claims the
bundle once and invokes the reviewed Ansible playbook through the repository
protected temporary-directory wrapper. The node refuses precondition drift and
insufficient remaining window before pausing writers.

## Independent acceptance

After the controller exits, collect bounded readback without opening secret values:

```sh
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=10 ama@10.1.2.170 'cd / && sudo -n /bin/bash -s' < readback.sh > readback.json 2> readback.stderr
python3 -B check-acceptance.py
```

Require zero controller status and independently compare both retained states:
`recovered_failure`, correct failure/deadline trigger, three zero resume statuses,
zero health status, recovery elapsed no more than 240 seconds, fault-to-recovery
no more than 690 seconds and no controller resume. Verify native writer health,
unchanged database/Redis invocations and boot, all old retained trees unchanged,
exactly two new staging runs, no new capture payload/upload, no transient credentials,
no qualification processes/runtime links and unchanged prior user/system timer
identities. Runtime hashes must match the frozen inputs. Check both calendar
receipts and the marker callback. Node receipts remain `accepted=false`; only all
independent checks permit accepted-state reconciliation.

## Failure and rollback boundary

Writer interruptions cannot be undone. Independent recovery owns resumption; there
is no rollback by deleting evidence. A controller disconnect leaves the node guard
available. On a failed case, preserve the runtime recovery units, state, claims and
staging; do not start the next case or replay the command. Do not clear latches,
remove recovery units, send compensating notifications, restore in place or delete
retained data. If native recovery fails, stop and report manual intervention;
additional recovery actions require a separate exact scope. This request includes
no discretionary production service changes beyond the reviewed recovery commands.

## Qualification and remaining gaps

Nine real local user-systemd cases passed: success, forced termination, guard
expiry, health taking longer than the old half-budget, preparation failure, timer
dispatch, the actual blocking fault helper, actual Ansible execution and termination
of the blocking fault through the real Ansible async path. The actual
timer helper and bundle refusal tests passed, as did 43 recurring regressions.
Local writers/provider are disposable adapters and local deadlines are shortened;
these results do not establish ARM64 production recovery, provider availability or
current target timing. Fresh target acceptance and independent cleanup remain open.

This stage qualifies fault recovery and timer mechanics. It does not establish an
unattended nightly run, host-outage alerting, populated-media recovery, weekly/monthly
schedules or remote retention deletion. Schedule enablement and terminal
commit/tag/push remain later, separately approved stages.

## Bound external read-only inputs

- `baseline.json`: `57240915b103da21b4c783754b2f5d79ae640c79f517fff92a3a4c8d58a006d5`
- `baseline.sh`: `37b15de0dd0e9fbde2a7879421911ed3f5df03eeee5e183705dfa10075c71cab`
- `check-baseline.py`: `ef6b6b14924d5054543ddb1109e1b2003db909268f3a87e58629c22e6b556be1`
- `readback.sh`: `4db37d676db1af97247274aa2e248ab8a70b1ac4af1e727c865d57a6171e1630`
- `check-acceptance.py`: `2d02f864d72687addb88801796302233b7967347beb789f0cce50ce95cce40cc`
