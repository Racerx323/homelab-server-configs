# Replacement recovery/timer qualification approval

Prepared only. Approve one execution of bundle `fbd8efebb45df6a95edebfa65f342cf451add9feef90767fedd8b6d292b35c85` for
`nautobot-recurring-recovery-timer-v2` on `ama@10.1.2.170` (`j2-svpi4mf`).
Repository execution remains disabled; this request does not itself authorize execution.

## Attended window

**November 3, 2026, 18:15–19:15 CST (America/Chicago).** Start the first trial
by **18:45 CST**. Aaron must be available throughout; exclude concurrent writer,
backup and maintenance work. If the window expires, do not edit or replay this bundle.
The two serial trials share a 1,800-second controller ceiling. Each retains the
450-second capture/guard deadline, shared 240-second recovery ceiling and native
210-second readiness limit within that remaining recovery budget.

## Exact retained-state and mutation boundary

The archived failed bundle is
`bb2e3c00d26e1bb1610c50ab1a680b835b6124ccdd471765ec198e0b38128043`.
Its root contains 19 frozen input files and six directories, including an empty
`killed` directory; no trial state, units, payload or credentials were created.
Before new setup, verify every bound hash, UID/GID/mode, boot, application invocation,
empty first-case directory, no pending user jobs and absence of all ten qualification
units/runtime links. Rename only
`/var/lib/nautobot/protection/recovery-qualification` to
`/var/lib/nautobot/protection/recovery-qualification-retained-bb2e3c00d26e`.
The destination must be absent. No deletion, overwrite or staging change is allowed.

Create a new protected service-owned root (UID 999/GID 985, directory mode 0700,
files 0600), transfer frozen inputs and capture each journal cursor through root
Ansible preflight without reading journal messages. Configure as Nautobot.
Run two faults once through the existing supervisor and real Ansible async path:

1. `killed`: native preparation, scheduler/web stop, worker drain/stop, then a
   blocking fault in place of capture. After pause and guard verification, kill
   only the primary qualification cgroup and observe independent OnFailure recovery.
2. `deadline`: after the first passes, repeat in separate state and let the
   450-second guard terminate the primary and recover writers without controller help.

After both pass, parse the two production calendar expressions around DST and run
one two-second marker-only timer. Remove only verified inactive qualification links.
No production schedule is enabled. PostgreSQL/Redis remain running throughout.

Use only the existing protected read-only Doppler token for `homelab-dev/prd_nautobot_backup`
(owner Aaron; expiry January 27, 2027; rotation due January 13). Resolve only:
`homelab-dev/prd_restic/NAUTOBOT_RESTIC_REPOSITORY_PASSWORD`,
`homelab-dev/prd_b2/NAUTOBOT_RESTIC_B2_APPLICATION_KEY_ID`, and
`homelab-dev/prd_b2/NAUTOBOT_RESTIC_B2_APPLICATION_KEY`.
Do not print values or create a provider configuration/token. Remove only the
four known transient credential files through the existing recovery path.

## Exact preflight and execution

From `/home/aaron/code/.local-evidence/nautobot-recovery-retained-preparation-20261103`, with `umask 077`, refresh the read-only baseline:

```sh
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=10 ama@10.1.2.170 'cd / && sudo -n /bin/bash -s' < baseline.sh > pre-execution.json 2> pre-execution.stderr
python3 -B check-baseline.py pre-execution.json > pre-execution-checks.json
```

Both must return zero. Confirm attendance, maintenance exclusion, the window and
an absent one-use claim/evidence directory. Execute exactly once:

```sh
python3 -B /home/aaron/code/.local-evidence/nautobot-recovery-retained-preparation-20261103/candidate/launcher.py execute /home/aaron/code/.local-evidence/nautobot-recovery-retained-preparation-20261103/candidate --approve fbd8efebb45df6a95edebfa65f342cf451add9feef90767fedd8b6d292b35c85 --evidence /home/aaron/code/.local-evidence/nautobot-recovery-retained-preparation-20261103/execution
```

## Acceptance and failure handling

Collect `readback.sh` through the same bounded read-only SSH command into
`readback.json`/`readback.stderr`, then run `python3 -B check-acceptance.py`.
Require controller zero; both states `recovered_failure` with the correct trigger;
all three resumes and health zero; recovery within 240 seconds; no transient
credential/payload/upload residue; unchanged boot, PostgreSQL/Redis invocations,
accepted artifacts/packages/media, prior evidence and original staging entries.
Require the renamed tree's exact baseline hashes/ownership/modes, exactly two new
staging runs, all ten qualification units/links absent, and the marker/calendar receipt.
Execution success alone is not acceptance.

Any failure stops the second case and timer phase. Before writer pause, preserve
both retained/new trees; do not delete inputs or rename back over a new tree.
After pause, the independent supervisor owns recovery within its existing bound.
Retain failed state, staging, claims and recovery units; if health/recovery cannot
be proved, report manual intervention and obtain scoped recovery authority.
No automatic replay, broad cleanup, reboot or package rollback is permitted.

## Evidence and remaining limits

Fresh read-only baseline, exact retained tree and timer comparisons passed.
The real disposable Debian SSH/sudo/user-systemd setup passed all six scenarios,
including journal denial/root cursor handoff, replay refusal, three drift refusals,
and preservation followed by both case setups. Fifteen retention regressions passed.
Application health/media are local adapters; this is not target recovery acceptance.
Prior native fault/async/guard/timer evidence is reused because those paths did not
change. The target must still prove independent recovery and marker dispatch.

Excluded: production schedule enablement, notifications, capture payloads, uploads,
remote Restic access/deletion/prune, older-payload disposal, package or monitoring
changes, SMART requests, reboot, and commit/tag/push. All older evidence and
consumed claims remain intact. A later publication requires separate authorization.
