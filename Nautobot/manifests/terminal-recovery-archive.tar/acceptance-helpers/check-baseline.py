import json,sys
from pathlib import Path
p=Path(__file__).resolve().parent
before=json.loads((p/'baseline.json').read_text());after=json.loads(Path(sys.argv[1]).read_text())
checks={k:after.get(k)==v for k,v in before.items() if k not in ('collected_at','staging_free_bytes','timers','system_timers')}
for k in ('timers','system_timers'):
 identity=lambda r:sorted((x['unit'],x['activates']) for x in json.loads(r[k]))
 checks[k]=identity(before)==identity(after)
checks['staging_capacity']=after['staging_free_bytes']>=64*1024**3
out={'passed':all(checks.values()),'checks':checks};print(json.dumps(out));raise SystemExit(0 if out['passed'] else 1)
