import json,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
before=json.loads((p/'pre-execution.json').read_text());after=json.loads((p/'readback.json').read_text());op=json.loads((p/'candidate/runtime/operation.json').read_text())
allowed={'collected_at','staging_free_bytes','timers','system_timers','services','staging_entries','recovery_qualification_absent','recovery_units','recovery_trials','recovery_units_after','recovery_links_after','timer_trial','recovery_runtime_sha256','retained_recovery_tree','retained_recovery_destination_absent'}
checks={'preserved_'+k:after.get(k)==v for k,v in before.items() if k not in allowed}
checks['retained_tree_preserved']=after['preserved_recovery_tree']==before['retained_recovery_tree']
checks['retained_destination_present']=after['retained_recovery_destination_absent'] is False
checks['controller_zero']=json.loads((p/'execution/controller-result.json').read_text())['exit_status']==0
for k in ('timers','system_timers'):
 identity=lambda r:sorted((x['unit'],x['activates']) for x in json.loads(r[k]))
 checks[k+'_unchanged']=identity(before)==identity(after)
checks['data_services_unchanged']=all(before['services']['nautobot-'+r+'.service']['InvocationID']==after['services']['nautobot-'+r+'.service']['InvocationID'] for r in ('postgresql','redis'))
for name,row in after['services'].items():checks[name+'_healthy']=row['ActiveState']=='active'
new_runs=[]
for case,t in after['recovery_trials'].items():
 s=t['state/state.json'];r=t['result.json'];fault=t['fault'];new_runs.append(Path(t['run_path']).name)
 checks[case+'_phase']=s['phase']=='recovered_failure'
 checks[case+'_trigger']=s['recovery_trigger']==('failure' if case=='killed' else 'deadline')
 checks[case+'_results']=s['resume_statuses']==[0,0,0] and s['health_status']==0 and s['credential_cleanup']
 checks[case+'_recovery_budget']=0<s['recovery_elapsed_seconds']<=240 and s['finished_at']-s['recovery_started_at']<=240
 checks[case+'_pause_budget']=fault['paused_at']<=s['recovery_started_at']<=s['finished_at'] and s['finished_at']-fault['paused_at']<=690
 checks[case+'_fault']=fault['case']==case and fault['boot_id']==before['boot_id']
 checks[case+'_no_credentials_payload_upload']=not t['credential_residue'] and not t['payload_exists'] and not t['upload_exists']
 checks[case+'_evidence']=r['checks_passed'] and r['accepted'] is False and r['controller_recovery_used'] is False
 checks[case+'_journal_cursor']=t['journal-cursor.json']['cursor'].startswith('-- cursor: ')
checks['only_new_runs']=sorted(set(after['staging_entries'])-set(before['staging_entries']))==sorted(new_runs) and set(before['staging_entries'])<=set(after['staging_entries']) and len(set(new_runs))==2
checks['units_absent']=all(r['LoadState']=='not-found' and r['ActiveState']=='inactive' and not r.get('ControlGroup') and all(r.get(k,'0')=='0' for k in ('MainPID','ControlPID')) for r in after['recovery_units_after'].values())
checks['links_absent']=not any(after['recovery_links_after'].values())
t=after['timer_trial'];checks['timer_callback']=t['dispatched'] and t['production_timer_enabled'] is False and t['accepted'] is False and len(t['calendar'])==4
runtime=p/'candidate/runtime';expected={str(f.relative_to(runtime)):hashlib.sha256(f.read_bytes()).hexdigest() for f in runtime.rglob('*') if f.is_file()}
checks['runtime_hashes']=after['recovery_runtime_sha256']==expected
out={'accepted':all(checks.values()),'checks':checks};(p/'acceptance-checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out));raise SystemExit(0 if out['accepted'] else 1)
