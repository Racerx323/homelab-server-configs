# Upload/integrity qualification — approval requested

Preparation only. No production upload or credential resolution has run.
Approve one attended execution of the frozen bundle below. No writer pause or
capture window is needed: this reuses the accepted November 3 capture.

## Exact identity and command

- Operation: `nautobot-recurring-upload-integrity-v1`
- Target: `ama@10.1.2.170` (`j2-svpi4mf`); runtime `nautobot` UID 999/GID 985.
- Bundle manifest SHA-256: `6b80008892b0d327c319fe93ba8d97dd6aa6f02e6641484d65715c0f3895e7a3`
- Candidate: `/home/aaron/code/.local-evidence/nautobot-upload-integrity-preparation-20261103/candidate`
- Source base: `6cda12864e8bdfa97c4fb69d0409e5351fde4558`; exact changed bytes are sealed in the bundle.
- Accepted capture bundle: `51ea37acf9bc9cc1fa3abe3f3abd4fb0b982eadca347031f53425439f84ea9af`.
- Retained payload: `/var/lib/nautobot/protection/staging/nautobot-recurring.usiv2ym1`.
- Repository: `s3:https://s3.us-west-002.backblazeb2.com/theama-homelab-nautobot-restic-prd/`
- Repository ID: `536d6d1dc29c7c6ea79eed972efb43cc37445fe0be73d0bf8518e2771394f8a9`, format 2.

```bash
python3 -B /home/aaron/code/.local-evidence/nautobot-upload-integrity-preparation-20261103/candidate/launcher.py execute /home/aaron/code/.local-evidence/nautobot-upload-integrity-preparation-20261103/candidate --approve 6b80008892b0d327c319fe93ba8d97dd6aa6f02e6641484d65715c0f3895e7a3 --evidence /home/aaron/code/.local-evidence/nautobot-upload-integrity-preparation-20261103/execution
```

The repository operation remains disabled. The candidate enables only this stage;
its hash does not grant approval by itself. The launcher consumes one exclusive
claim before Ansible runs. An existing node evidence directory or changed retained
state refuses execution. No automatic retry or transfer-only follow-up is needed.

## Authorized mutation boundary if approved

One playbook creates `/var/lib/nautobot/protection/upload-qualification` (999:985,
0700), copies the sealed runtime files (0600), and runs one transient user service
`nautobot-protection-upload-qualification.service`. No persistent unit or timer is
installed. It locks the existing capture run lock without rewriting its contents.

Resolve only the three canonical references through the already accepted Doppler
service token: `NAUTOBOT_RESTIC_REPOSITORY_PASSWORD`,
`NAUTOBOT_RESTIC_B2_APPLICATION_KEY_ID`, and `NAUTOBOT_RESTIC_B2_APPLICATION_KEY`,
project `homelab-dev`, config `prd_nautobot_backup`. The existing token is read-only
and config-scoped, expires January 27, 2027; Aaron owns rotation due January 13.
No provider configuration, key or token is created or changed.

Temporary `source-password`, `source-credentials.json`, `password` and
`credentials.json` files may be created only in the retained payload root, owned
by Nautobot with mode 0600. The resolver may create a temporary empty home directory
there. Secrets are never placed in arguments, output, bundle hashes or receipts.
The original capture specification, receipt and six payload files are preserved.
Only producer upload/snapshot receipts are added to that root.

Restic may write encrypted backup data/index/snapshot objects into the exact
existing repository, and create/remove its normal backup/check locks. Verify the
repository identity before backup, require exactly one new full snapshot ID,
then run full `check --read-data`. Use the existing no-cache producer. No init,
restore, unlock, repair, snapshot deletion, forget or prune is authorized.

The original **300-second total producer deadline** is unchanged. The transient
service has **420 seconds** total runtime plus **30 seconds** to stop its cgroup;
stop-post cleanup attempts all four owned credential removals. The controller
transport has its existing 1500-second outer timeout. No writer service is
stopped/restarted and no notification or schedule is enabled.

## Acceptance and failure handling

Require zero upload/full-check status; one exact full snapshot ID with the sealed
hostname/path/tag; unchanged six payload hashes and original capture files;
repository locks absent at producer completion; successful owned-credential
cleanup; unchanged boot and all five service invocations, HTTP health and accepted
application artifacts; inactive transient unit; unchanged older payloads, retained
trees/latches, runtime links and timer identities.

Independently collect bounded node readback with `/home/aaron/code/.local-evidence/nautobot-upload-integrity-preparation-20261103/readback.sh`, then run
`python3 -B /home/aaron/code/.local-evidence/nautobot-upload-integrity-preparation-20261103/check-acceptance.py`. The collector refuses secret paths before
reading file contents. These read-only acceptance helpers are external review
inputs with these SHA-256 identities:

- `readback.sh`: `f113711c31802c8127f7d69489025069c5843752bb30aa69deed9c0607a2c1b7`
- `check-acceptance.py`: `d3ced8d49b035c36162de85f18b52dfc601093d421d9cc81002a147b3f249930`

Readback command (after the one execution, writing fresh protected files):

```bash
umask 077
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=10 ama@10.1.2.170 'cd / && sudo -n /bin/bash -s' < /home/aaron/code/.local-evidence/nautobot-upload-integrity-preparation-20261103/readback.sh > /home/aaron/code/.local-evidence/nautobot-upload-integrity-preparation-20261103/readback.json 2> /home/aaron/code/.local-evidence/nautobot-upload-integrity-preparation-20261103/readback.stderr
python3 -B /home/aaron/code/.local-evidence/nautobot-upload-integrity-preparation-20261103/check-acceptance.py
```

On any failure, retain every payload, snapshot, repository object and receipt.
Clean up only transient credentials whose ownership was proved. There is no
remote rollback or automatic retry. Timeout may leave a snapshot of uncertain
identity or a repository lock; diagnose read-only before any new mutation.
A cleanup failure requires attended review and bounded credential removal; do not
remove an unowned pre-existing file or delete retained payloads.

## Evidence and remaining prerequisites

Fresh read-only target observations at 13:45 and 13:59 CST on November 3 matched
the accepted capture, service identities, artifacts and credential metadata;
the upload evidence directory is absent and its unit is inactive. No SMART,
secret-value, provider or remote repository request was made during preparation.

Local qualification exercised real PostgreSQL dump/parser, Restic 0.18.0,
Ansible playbook, credential resolver and user-systemd. Success/full integrity,
replay refusal, payload/service drift, pre-existing-secret preservation,
post-snapshot check failure and native timeout cleanup passed. Application health
and the Doppler endpoint use disposable local adapters. This is not ARM64 target
acceptance or evidence of current remote credentials/repository performance.

Before execution: obtain this exact approval, attend the run, retain working SSH/
sudo access, require the frozen baseline still matches, and have existing Doppler
and B2 credentials valid. Their values are supplied only through the accepted
protected delivery path. Full B2 repository checking within 300 seconds remains
unqualified; do not extend the immutable capture specification if it times out.

Later stages remain unauthorized: notifications, disposal, retention, recurring
schedule enablement, populated-media recovery, new capture/restore, package or
monitoring changes, reboot and terminal Git publication.
