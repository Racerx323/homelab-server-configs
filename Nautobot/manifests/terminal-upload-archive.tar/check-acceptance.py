import json,sys
from pathlib import Path
base=Path(__file__).resolve().parent
before=json.loads((base/'baseline.json').read_text())
after=json.loads((base/'readback.json').read_text())
checks={}
for key in ('boot_id','uid','gid','services','qualification','state','credential_file_metadata','media_directories',
            'old_payload','previous_readiness_payload','earlier_retained','preserved_terminal','preserved_readiness_terminal',
            'staging_entries','links','runtime_links_present','capture_specification','task_results','resume_verification'):
    checks['unchanged_'+key]=before[key]==after[key]
for key in ('artifacts_match','binding_artifacts_match','credential_metadata_match','packages_match','payload_hashes_match','native_dump_valid'):
    checks[key]=after[key] is True
old=before['payload'];new=after['payload']
checks['original_files_unchanged']=all(new['files'].get(n)==v for n,v in old['files'].items())
checks['directories_unchanged']=new['directories']==old['directories']
checks['only_upload_receipts_added']=set(new['files'])-set(old['files'])=={
    'application-backup-started.json','application-snapshots-before.json','application-upload-attempt.json',
    'application-snapshots-after.json','application-backup-result.json'}
receipt=after['upload_receipts']['application-backup-result.json']
prior=set(after['upload_receipts']['application-snapshots-before.json']);latest=set(after['upload_receipts']['application-snapshots-after.json'])
checks['one_snapshot']=prior.issubset(latest) and latest-prior=={receipt['snapshot_id']} and len(receipt['snapshot_id'])==64
checks['upload_and_full_integrity']=receipt['backup_exit_status']==0 and receipt['integrity_exit_status']==0 and receipt['integrity_passed'] is True
checks['content_hashes']=receipt['content_sha256']==json.loads((base/'candidate/runtime/operation.json').read_text())['content_sha256']
checks['cleanup']=all(receipt['credential_cleanup'].values()) and all(after['upload_cleanup'].values())
checks['helper_completed']=after['upload_result'].get('checks_passed') is True
checks['unit_stopped']=after['upload_unit']['ActiveState']=='inactive' and after['upload_unit']['MainPID']=='0' and after['upload_unit']['ControlPID']=='0' and not after['upload_unit']['ControlGroup']
checks['no_new_timers']={(r['unit'],r['activates']) for r in json.loads(before['timers'])}=={(r['unit'],r['activates']) for r in json.loads(after['timers'])}
checks['no_secret_read']=after['secret_values_read'] is False
result={'checks':checks,'accepted':all(checks.values()),'snapshot_id':receipt['snapshot_id']}
(base/'acceptance-checks.json').write_text(json.dumps(result,indent=2)+'\n')
sys.exit(0 if result['accepted'] else 1)
