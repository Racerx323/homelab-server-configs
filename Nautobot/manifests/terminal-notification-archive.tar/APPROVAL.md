# Notification-delivery qualification approval request

Status: prepared; not authorized or executed. No production notifications were sent.

Approve one execution of bundle `b8f23ba87807b194080d0836a44858fef87084d4b49c7ea55d0ba05e26490aed` on `ama@10.1.2.170`
(`j2-svpi4mf`), as service account Nautobot (UID 999, GID 985).
Source base: `587a44482a17c23c7e41f7a545718cfff2838f1b` plus the exact frozen files in
`candidate/bundle.json`. The repository operation remains disabled. The frozen
execution candidate is usable only after explicit approval of this request.

## Destination and content

POST only to `http://10.1.3.83:8000/notify/apprise`, using its existing persistent
`apprise` configuration. Aaron attests that it sends email, Discord server and
Pushover notifications, and will confirm receipt on all three. That attestation
binds the existing destination; no additional mailbox, channel, device, provider
URL or token is needed. Provider configuration has not been inspected or changed.
No tags or routing overrides are supplied. No attachments.

The following are the complete two message previews. `type` is `failure` then
`success`; `format` is `text`. The Idempotency-Key equals the correlation shown.
The test reference timestamp is frozen preview content, not an actual incident time.

### Simulated failure

Subject/title: [QUALIFICATION] 🚨 [Nautobot] Failure on j2-svpi4mf

```text
Summary
- Node: j2-svpi4mf.local.theama.co
- Component: recurring application backup
- Simulated event: failure
- State: unknown -> failure

Impact
Notification delivery test only. No production incident or recovery is claimed.

Details
- Check: nightly-protection
- Failure class: backup-or-writer-recovery
- Test reference time: 2026-11-03T20:41:49.652134+00:00
- Correlation: d869688ae3690ea2584f1166fe4a948188039f1a3ec22754227d9df40a559210


Next step
- Aaron: confirm this correlation on email, Discord and Pushover.
- No application action is required.
```

### Simulated recovery

Subject/title: [QUALIFICATION] ✅ [Nautobot] Recovery on j2-svpi4mf

```text
Summary
- Node: j2-svpi4mf.local.theama.co
- Component: recurring application backup
- Simulated event: recovery
- State: failure -> recovery

Impact
Notification delivery test only. No production incident or recovery is claimed.

Details
- Check: nightly-protection
- Failure class: none
- Test reference time: 2026-11-03T20:41:49.652134+00:00
- Correlation: 57a1a9d7e4212a45827892e3eb28c30e124f975887166943de42d144946926cc


Next step
- Aaron: confirm this correlation on email, Discord and Pushover.
- No application action is required.
```

## Exact execution command

```sh
python3 -B /home/aaron/code/.local-evidence/nautobot-notification-preparation-20261103/candidate/launcher.py execute /home/aaron/code/.local-evidence/nautobot-notification-preparation-20261103/candidate --approve b8f23ba87807b194080d0836a44858fef87084d4b49c7ea55d0ba05e26490aed --evidence /home/aaron/code/.local-evidence/nautobot-notification-preparation-20261103/execution
```

Run from the protected request directory with `umask 077`. The launcher verifies
all bundle files and the pinned controller executable, claims this bundle once,
and invokes one Ansible playbook through the repository temporary-directory
wrapper. Do not re-freeze or edit the candidate after approval.

Before that command, refresh the bounded read-only baseline and compare it:

```sh
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=10 ama@10.1.2.170 'cd / && sudo -n /bin/bash -s' < /home/aaron/code/.local-evidence/nautobot-notification-preparation-20261103/baseline.sh > /home/aaron/code/.local-evidence/nautobot-notification-preparation-20261103/pre-execution.json 2> /home/aaron/code/.local-evidence/nautobot-notification-preparation-20261103/pre-execution.stderr
python3 -B /home/aaron/code/.local-evidence/nautobot-notification-preparation-20261103/check-baseline.py /home/aaron/code/.local-evidence/nautobot-notification-preparation-20261103/pre-execution.json
```

Proceed only if both commands exit zero. Drift stops the stage before transfer.
The prepared baseline was collected at `2026-11-03T20:41:49.652134+00:00`. Forty-two
comparisons passed against the accepted upload readback, including timer identities;
free capacity and timer countdowns are dynamic. All application/retained-state
comparisons matched. No SMART requests or secret values were read.

## Ordered mutation boundary and retries

1. Create only `/var/lib/nautobot/protection/notification-qualification` and its
   service-owned 0700 subdirectories; copy frozen runtime inputs with 0600 files.
   Existing evidence or queue paths are refused.
2. Start only `nautobot-notification-qualification.service`, a transient user unit,
   with a 180-second runtime limit, 10-second stop limit and control-group kill.
   Read-only checks verify boot, identity, healthy service invocations, HTTP health
   and exact accepted capture/payload trees before any POST.
3. Send simulated failure, then simulated recovery only after failure's HTTP 200.
   Each has at most two attempts, 15 seconds apart; at most four POSTs total.
   Each socket operation has a five-second timeout. The unit bounds total runtime.
   Retries preserve exact content and correlation; redirects are refused.
4. Record attempts and queue state as protected 0600 files, compare preserved
   state and health again, and exit. No scheduled retry or notification timer is
   installed. Exhaustion retains pending state and prevents further sends.

A lost HTTP response can cause duplicate downstream messages. The idempotency
header does not guarantee deduplication. There is no automatic retry after HTTP
200 merely because a downstream receipt is missing. Existing production backup
state, latches, payloads, credentials, timers, routing and monitoring stay unchanged.
No package changes, writers paused, backups, Restic access, provider-token reads,
reboots, disposal, retention changes, commit/tag/push or later-stage execution.

## Independent delivery evidence and acceptance

After the bounded execution, collect independent readback:

```sh
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=10 ama@10.1.2.170 'cd / && sudo -n /bin/bash -s' < /home/aaron/code/.local-evidence/nautobot-notification-preparation-20261103/readback.sh > /home/aaron/code/.local-evidence/nautobot-notification-preparation-20261103/readback.json 2> /home/aaron/code/.local-evidence/nautobot-notification-preparation-20261103/readback.stderr
```

Require controller exit zero; both events submitted with HTTP 200 within the
attempt bounds; a drained isolated queue; healthy unchanged application services;
unchanged capture, payload, prior retained trees/latches and timer identities;
protected evidence; and an inactive notification unit with no remaining processes.
The node's `accepted` stays false: HTTP 200 is submission evidence only. A false
HTTP result does not distinguish non-200 status from transport failure; no raw
response bodies or provider secrets are captured.

Aaron confirms the failure and recovery correlation on **each of email, Discord
and Pushover**, with receipt times/timezone and any duplicates, within ten minutes
of the corresponding send starting. Record only these non-secret confirmations in
`receipt-confirmations.json`, whose six entries start unconfirmed. No screenshots,
mailbox addresses, provider URLs or tokens are required. Missing receipts mean
incomplete qualification; stop without sending more. Late receipts remain recorded
as late and do not satisfy the ten-minute bound.

Then run:

```sh
python3 -B /home/aaron/code/.local-evidence/nautobot-notification-preparation-20261103/check-acceptance.py
```

Only all passing independent checks plus Aaron's six confirmations permit accepted
live-state reconciliation. Raw evidence stays outside Git; terminal archival is a
separate publication action.

## Failure and rollback boundary

Already delivered messages cannot be recalled. Cancellation, exhausted attempts,
service/retained-state drift or missing downstream receipts stop this qualification;
retain the queue and evidence and report the exact failing boundary. Do not send
compensating messages or replay the consumed bundle. If still active, stop only
this transient unit through the Nautobot user bus:

```sh
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=10 ama@10.1.2.170 'sudo -n /usr/sbin/runuser --user nautobot -- /usr/bin/env HOME=/var/lib/nautobot XDG_RUNTIME_DIR=/run/user/999 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/999/bus /usr/bin/systemctl --user stop nautobot-notification-qualification.service'
```

Verify it has no processes. Preserve all evidence and payloads. No application
rollback, route edits or cleanup deletes are included. Another send requires a
new, separately scoped request after diagnosis.

## Local qualification and remaining gaps

Nine notification tests passed, including actual loopback HTTP, exact content,
retry/exhaustion, four-request ceiling, boot/message drift, cancellation, bundle
integrity and the real Ansible/transient-service path with replay refusal. The
native test adapts only the local account, endpoint and local D-Bus health probe;
it does not claim target Podman or downstream delivery acceptance. Existing
recurring media/bindings/supervisor/disposal regressions: 43 passed. Operation
contracts: 16; documentation: 5; host convergence: 16. Ansible syntax, assertion
policy and bundle secret scan passed.

Remaining inputs are explicit approval of this bundle and Aaron's availability
to observe its two messages. Current routing is operator-attested; target HTTP
submission and all six downstream receipts remain unqualified. There is no new
credential-provisioning prerequisite. Disposal, retention, remaining recovery gates
and schedule enablement remain later stages.

## Bound external read-only inputs

These support fresh preflight and independent acceptance; they do not send:

- `baseline.json`: `7513f78e4e24f70b8df4e20e910bbb85e38faa577ec8ac3f14378199e84d34f0`
- `baseline.sh`: `4e2a4bf1ef99f07f9b66c4276c7d755d393461d64001f08cd3eb43c93fba84a5`
- `check-baseline.py`: `9f34793c1844db9d9fc90a92e23effbd50a35961404dcb62672b49f54c39f703`
- `readback.sh`: `f8af5f5bde06e85242836918b7a4f2e468f78486742db62a7ddc02ba2d8b2f42`
- `check-acceptance.py`: `f26b1fcb6c4950da1e4aaed9d9a23a13a88f6d88e75a8957696321b4da18d79c`

Local evidence hashes are recorded in `Nautobot/manifests/recurring-notification-review.json`.
