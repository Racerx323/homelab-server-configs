"""Independent readback comparison; human receipts are external evidence."""
import json
from datetime import datetime
from pathlib import Path
root=Path(__file__).resolve().parent
before=json.loads((root/'baseline.json').read_text())
after=json.loads((root/'readback.json').read_text())
op=json.loads((root/'candidate/runtime/operation.json').read_text())
ignored={'collected_at','staging_free_bytes','timers','notification_evidence_absent','notification_unit'}
checks={'preserved_'+key:before[key]==after.get(key) for key in before if key not in ignored}
timers=lambda x:sorted((t['unit'],t['activates']) for t in json.loads(x['timers']))
checks['timer_identities']=timers(before)==timers(after)
unit=after['notification_unit'];checks['unit_inactive']=unit['ActiveState']=='inactive' and unit['MainPID']=='0' and unit['ControlPID']=='0' and not unit['ControlGroup']
checks['controller_exit_zero']=json.loads((root/'execution/controller-result.json').read_text())['exit_status']==0
result=after['notification_result'];queue=after['notification_queue']
checks['submission_complete']=result['submission_complete'] and result['checks_passed'] and result['accepted'] is False
checks['queue_drained']=queue['acknowledged']=='recovery' and queue['sequence']==2 and queue['pending'] is None
attempts=result['attempts'];checks['bounded_attempts']=2<=len(attempts)<=4
checks['ordered_events']=[r['event'] for r in attempts] in [['failure','recovery'],['failure','failure','recovery'],['failure','recovery','recovery'],['failure','failure','recovery','recovery']]
for event in ('failure','recovery'):
 rows=[r for r in attempts if r['event']==event]
 checks[event+'_submission']=1<=len(rows)<=2 and rows[-1]['http_200'] is True and all(r['event_id']==op['messages'][event]['event_id'] for r in rows)
checks['protected_evidence']=all(r['uid']==999 and r['gid']==985 and r['mode']==mode for kind,mode in [('files',384),('directories',448)] for r in after['notification_tree'][kind].values())
human=json.loads((root/'receipt-confirmations.json').read_text())
checks['witness']=human['witness']=='Aaron'
checks['receipt_scope']=len(human['receipts'])==6 and {(r['event'],r['destination']) for r in human['receipts']}=={(e,d) for e in ('failure','recovery') for d in ('email','Discord','Pushover')}
for row in human['receipts']:
 key=row['event']+'_'+row['destination'];checks[key]=False
 if row['confirmed'] is True and row['event_id']==op['messages'][row['event']]['event_id'] and row['received_at']:
  receipt=datetime.fromisoformat(row['received_at']);start=datetime.fromisoformat(next(r['started_at'] for r in attempts if r['event']==row['event']))
  checks[key]=receipt.tzinfo is not None and 0<=(receipt-start).total_seconds()<=op['receipt_wait_seconds']
report={'accepted':all(checks.values()),'checks':checks}
(root/'acceptance-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report));raise SystemExit(0 if report['accepted'] else 1)
